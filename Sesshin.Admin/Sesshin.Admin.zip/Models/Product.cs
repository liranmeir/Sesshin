﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sesshin.Admin.Models
{
    public class Product
    {
        [Key]
        public int ID { get; set; }
        [Required]
        [DisplayName("שם מוצר")]
        public string Name { get; set; }
        [DisplayName("תאור")]
        [AllowHtml]
        public string Description { get; set; }
        [DisplayName("קבצי רקע")]
        public string BackgroundFiles { get; set; }
        [DisplayName("תאריך עדכון")]
        public DateTime DateModified { get; set; }

        public virtual ICollection<PriceModel> PriceModels { get; set; } 

        [DisplayName("כותרת עמוד ")]
        public string PageTitle { get; set; }
        [DisplayName("תאור עמוד")]
        public string PageDescription { get; set; }
        [DisplayName("מילות מפתח")]
        public string PageKeywords { get; set; }

        
    }

    public class PriceModel
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string SubTitle { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }

        public int ProductID { get; set; }
        public Product Product { get; set; }

    }
}