﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sesshin.Admin.Models
{
    public class Article
    {
        [Key]
        public int ID { get; set; }
        [Required]
        [DisplayName("שם כתבה")]
        public string Name { get; set; }
        [DisplayName("כותרת עמוד ")]
        public string PageTitle { get; set; }
        [DisplayName("תאור עמוד")]
        public string PageDescription { get; set; }
        [DisplayName("מילות מפתח")]
        public string PageKeywords { get; set; }


        [DisplayName("כותרת")]
        public string Headline { get; set; }
        [DisplayName("תוכן")]
        [AllowHtml]
        public string Content { get; set; }
        [DisplayName("תאריך")]
        public DateTime DateCreated { get; set; }
    }
}